(function($){
    $(function(){

        $('.sidenav').sidenav();

  }); // end of document ready
})(jQuery); // end of jQuery name space

$(document).ready(function(){
    $('select').formSelect();
})
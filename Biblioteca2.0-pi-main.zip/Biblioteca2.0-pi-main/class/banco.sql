<--!atualização do banco -->
CREATE TABLE sugestao( id int NOT null AUTO_INCREMENT PRIMARY key, nome varchar(200) not null, sugestao text NOT null )